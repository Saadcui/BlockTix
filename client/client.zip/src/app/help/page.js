import React from 'react'

function HelpCenter() {
  return (
    <div>Help Center</div>
  )
}

export default HelpCenter